#### v0.9.25 (2016-03-01)
- Fix a bug in rARTP when none of the SNPs in a gene can pass the data cleaning threshold specified in options. This bug only affects rARTP. Add a new function exclude.snps

#### v0.9.22 (2016-02-11)
- Rename the main functions to be rARTP (raw data input), sARTP (summary data input), and warm.start so that it is consistent with our journal paper

#### v0.9.21 (2016-02-11)
- First stable submission to CRAN
