# ARTP2

[![CRAN version](http://www.r-pkg.org/badges/version/ARTP2)](http://www.r-pkg.org/pkg/ARTP2)
[![CRAN RStudio mirror downloads](http://cranlogs.r-pkg.org/badges/grand-total/ARTP2)](http://www.r-pkg.org/pkg/ARTP2)

An enhanced R package of biological pathway analysis and pathway meta-analysis for genome-wide association studies. 

