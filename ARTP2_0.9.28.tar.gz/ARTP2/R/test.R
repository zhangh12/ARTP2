# this code is used to test C++ feature

test <- function(){
  
  tmp <- .C("test", PACKAGE = "ARTP2")
  
}
